% Load the data
load('m_pokus2.mat', 'u', 'y');

% Define the inputs for each neural network
P1 = [y(3:end-1)'; y(2:end-2)'; y(1:end-3)'; u(3:end-1)'; u(2:end-2)'; u(1:end-3)'];
T1 = y(4:end)';

% Define and train each neural network
nets = {};
for i = 1:4
    net = newff(minmax(P1), [3, 5, 1], {'logsig', 'tansig', 'purelin'}, 'trainlm');
    net = init(net);
    net.trainParam.show = 1;
    net.trainParam.epochs = 1000;
    net.trainParam.goal = 1e-12;
    net.trainParam.max_fail = 1000;
    nets{i} = train(net, P1, T1);
end

% Plot responses for each network
figure;
for i = 1:4
    subplot(2, 2, i);
    outputs = sim(nets{i}, P1);
    plot(T1, 'r'); hold on;
    plot(outputs, 'b');
    title(['Network ' num2str(i)]);
    legend('True Output', 'Network Output');
    xlabel('Time');
    ylabel('Output');
    grid on;
end
