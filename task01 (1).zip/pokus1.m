% Define the sampling time
Ts = 0.2;

% Run simulation with noise off
set_param('pokus/Noise Switch', 'sw', '0');
sim('pokus.slx');

% Retrieve logged data
u = out.Input1;  % Assuming out.input logs the input signal
y = out.Output1; % Assuming out.output logs the output signal

% Save data without noise
save('pokus1.mat', 'Ts', 'u', 'y');
