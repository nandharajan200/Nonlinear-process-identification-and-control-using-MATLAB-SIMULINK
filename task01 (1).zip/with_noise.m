clear; clc;

%% parametri
Ts = 0.2;

%% Load data
load('pokus2.mat'); % Assuming u and y are stored in pokus2.mat

% Ensure y and u have the same length
min_length = min(length(y), length(u));
y = y(1:min_length);
u = u(1:min_length);

%% priprema podataka za ucenje

P = [y(3:end-1)'; y(2:end-2)'; y(1:end-3)'; u(3:end-1)'; u(2:end-2)'; u(1:end-3)'];
T = y(4:end)';

% Ensure P and T have compatible dimensions
if size(P, 2) ~= length(T)
    error('Inconsistent dimensions between P and T');
end

%% bez regularizacije
net2 = feedforwardnet(20);
net2.divideFcn = ''; % No data division
net2 = configure(net2, P, T);
net2 = train(net2, P, T);
save('trained_net2.mat', 'net2');
gensim(net2, Ts);

%% implicitna regularizacija
net3 = feedforwardnet(20);
net3.divideFcn = 'dividerand'; % Data division function
net3.divideParam.trainRatio = 0.7; % Training set ratio
net3.divideParam.valRatio = 0.3; % Validation set ratio
net3 = configure(net3, P, T);
net3 = train(net3, P, T);
save('trained_net3.mat', 'net3');
gensim(net3, Ts);

%% eksplicitna regularizacija
net4 = feedforwardnet(20);
net4.divideFcn = 'dividerand'; % Data division function
net4.divideParam.trainRatio = 0.7; % Training set ratio
net4.divideParam.valRatio = 0.15; % Validation set ratio
net4.divideParam.testRatio = 0.15; % Test set ratio
net4.performParam.normalization = 'none';
net4.performParam.regularization = 1e-5; % Explicit regularization
net4 = train(net4, P, T);
save('trained_net4.mat', 'net4');
gensim(net4, Ts);
