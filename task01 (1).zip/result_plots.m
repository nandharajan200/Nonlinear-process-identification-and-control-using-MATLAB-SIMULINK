% Load trained networks
load('trained_net1.mat', 'net1');
load('trained_net2.mat', 'net2');
load('trained_net3.mat', 'net3');
load('trained_net4.mat', 'net4');

% Simulate the networks
output1 = net1(P);
output2 = net2(P);
output3 = net3(P);
output4 = net4(P);

% Smooth the outputs
output1_smooth = smoothdata(output1, 'movmean', 20); % Adjust window size if needed
output2_smooth = smoothdata(output2, 'movmean', 20);
output3_smooth = smoothdata(output3, 'movmean', 20);
output4_smooth = smoothdata(output4, 'movmean', 20);

% Smooth the actual signal
T_smooth = smoothdata(T, 'movmean', 20); % Adjust window size if needed

% Add noise to the outputs
noise = 0.1 * randn(size(T));
output1_noisy = output1 + noise;
output2_noisy = output2 + noise;
output3_noisy = output3 + noise;
output4_noisy = output4 + noise;

% Plot the outputs without noise
figure;
subplot(2, 2, 1);
plot(T_smooth, 'b', 'DisplayName', 'Actual');
hold on;
plot(output1_smooth, 'r', 'DisplayName', 'NN1 Output');
title('NN1 Output without Noise');
legend;
grid on;

subplot(2, 2, 2);
plot(T_smooth, 'b', 'DisplayName', 'Actual');
hold on;
plot(output2_smooth, 'g', 'DisplayName', 'NN2 Output');
title('NN2 Output without Noise');
legend;
grid on;

subplot(2, 2, 3);
plot(T_smooth, 'b', 'DisplayName', 'Actual');
hold on;
plot(output3_smooth, 'm', 'DisplayName', 'NN3 Output');
title('NN3 Output without Noise');
legend;
grid on;

subplot(2, 2, 4);
plot(T_smooth, 'b', 'DisplayName', 'Actual');
hold on;
plot(output4_smooth, 'k', 'DisplayName', 'NN4 Output');
title('NN4 Output without Noise');
legend;
grid on;

% Save the figure without noise
saveas(gcf, 'NN_Outputs_without_Noise.png');

% Plot the outputs with noise
figure;
subplot(2, 2, 1);
plot(T_smooth, 'b', 'DisplayName', 'Actual');
hold on;
plot(output1_noisy, 'r', 'DisplayName', 'NN1 Output with Noise');
title('NN1 Output with Noise');
legend;
grid on;

subplot(2, 2, 2);
plot(T_smooth, 'b', 'DisplayName', 'Actual');
hold on;
plot(output2_noisy, 'g', 'DisplayName', 'NN2 Output with Noise');
title('NN2 Output with Noise');
legend;
grid on;

subplot(2, 2, 3);
plot(T_smooth, 'b', 'DisplayName', 'Actual');
hold on;
plot(output3_noisy, 'm', 'DisplayName', 'NN3 Output with Noise');
title('NN3 Output with Noise');
legend;
grid on;

subplot(2, 2, 4);
plot(T_smooth, 'b', 'DisplayName', 'Actual');
hold on;
plot(output4_noisy, 'k', 'DisplayName', 'NN4 Output with Noise');
title('NN4 Output with Noise');
legend;
grid on;

% Save the figure with noise
saveas(gcf, 'NN_Outputs_with_Noise.png');
