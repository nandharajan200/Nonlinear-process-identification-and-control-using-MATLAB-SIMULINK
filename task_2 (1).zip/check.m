% Example data, replace with actual simulation results
time = 0:0.1:20;
response_without_prefilter = sin(0.2 * time); % replace with actual data
response_with_prefilter = sin(0.2 * time) .* exp(-0.05 * time); % replace with actual data

% Plotting the response with and without pre-filter
figure;
plot(time, response_without_prefilter, 'r', 'DisplayName', 'Without Pre-filter');
hold on;
plot(time, response_with_prefilter, 'b', 'DisplayName', 'With Pre-filter');
xlabel('Time (s)');
ylabel('Output');
title('System Response with and without Pre-filter');
legend;
grid on;

% Example data for internal model testing
response_narx = sin(0.2 * time) + 0.1 * randn(size(time)); % replace with actual data
response_noe = sin(0.2 * time) + 0.05 * randn(size(time)); % replace with actual data

% Plotting the response with NARX and NOE structures
figure;
plot(time, response_narx, 'r', 'DisplayName', 'NARX');
hold on;
plot(time, response_noe, 'b', 'DisplayName', 'NOE');
xlabel('Time (s)');
ylabel('Output');
title('System Response with NARX and NOE Structures');
legend;
grid on;
