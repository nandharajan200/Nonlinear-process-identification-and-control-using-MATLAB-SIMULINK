% Run simulation with noise on
set_param('pokus/Noise Switch', 'sw', '1');
sim('inv_pokus.slx');

% Retrieve logged data
u = out.Input1;  % Assuming out.input logs the input signal
y = out.Output1; % Assuming out.output logs the output signal

% Save data with noise
save('inv_pokus2.mat', 'Ts', 'u', 'y');