
% Load data from pokus1.mat
load('inv_pokus1.mat', 'u', 'y');

% Prepare input matrix P and output vector T for the inverse model
% Here y becomes input and u becomes output
P = [y(4:end)'; y(3:end-1)'; y(2:end-2)'; y(1:end-3)'; u(2:end-2)'; u(1:end-3)'];
T = u(3:end-1)';


% Smooth the input matrix P and output vector T
P_smooth = smoothdata(P, 2, 'movmean', 20); % Adjust window size if needed
T_smooth = smoothdata(T, 'movmean', 20); % Adjust window size if needed

% Define and train Neural Network 1
net1 = feedforwardnet(20);
net1 = newff(minmax(P_smooth), [3, 5, 1], {'logsig', 'tansig', 'purelin'}, 'trainlm');
net1 = init(net1); % Initialize the network (weights and biases)
net1.trainParam.show = 1; % Display training progress at each iteration (epoch)
net1.trainParam.epochs = 1000; % Maximum number of training iterations
net1.trainParam.goal = 1e-12; % Training goal based on error (mse)
net1.trainParam.max_fail = 1000; % Maximum validation failures before stopping

% Train the neural network
net1 = train(net1, P_smooth, T_smooth);

% Save the trained network
save('trained_net1.mat', 'net1');

% Generate a Simulink block for the trained network
gensim(net1, -1);

